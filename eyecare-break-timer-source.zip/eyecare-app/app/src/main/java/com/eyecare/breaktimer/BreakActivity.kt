package com.eyecare.breaktimer

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * The full-screen break overlay. In Strict Mode the Skip button is not shown
 * and the back button is swallowed, so the only way through is to wait out
 * the timer. (A regular, non-device-owner app cannot also block the Home /
 * Recents buttons — that requires Android's kiosk/lock-task APIs, which need
 * the app to be set as device owner. This is a real OS limitation, documented
 * in the README rather than silently glossed over.)
 */
class BreakActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_BREAK_SECONDS = "break_seconds"
        const val EXTRA_STRICT_MODE = "strict_mode"
    }

    private var timer: CountDownTimer? = null
    private var strictMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        setContentView(R.layout.activity_break)

        val breakSeconds = intent.getIntExtra(EXTRA_BREAK_SECONDS, 20)
        strictMode = intent.getBooleanExtra(EXTRA_STRICT_MODE, false)

        val countdownText = findViewById<TextView>(R.id.textCountdown)
        val messageText = findViewById<TextView>(R.id.textMessage)
        val skipButton = findViewById<Button>(R.id.buttonSkip)

        messageText.text = getString(R.string.break_message)

        if (strictMode) {
            skipButton.visibility = View.GONE
        } else {
            skipButton.setOnClickListener { skipBreakEarly() }
        }

        timer = object : CountDownTimer(breakSeconds * 1000L, 1000L) {
            override fun onTick(msLeft: Long) {
                val s = (msLeft / 1000).toInt()
                countdownText.text = String.format("%02d:%02d", s / 60, s % 60)
            }
            override fun onFinish() {
                // The service's own break timer finishes at the same moment and
                // moves itself on to the next work phase; this screen just closes.
                countdownText.text = "00:00"
                finish()
            }
        }.start()
    }

    private fun skipBreakEarly() {
        timer?.cancel()
        val intent = Intent(this, TimerService::class.java).apply {
            action = TimerService.ACTION_SKIP_BREAK
        }
        ContextCompat.startForegroundService(this, intent)
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (strictMode) return // Strict Mode: the break cannot be dismissed early.
        skipBreakEarly()
    }

    override fun onDestroy() {
        timer?.cancel()
        super.onDestroy()
    }
}
