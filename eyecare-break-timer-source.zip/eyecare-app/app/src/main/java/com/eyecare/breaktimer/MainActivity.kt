package com.eyecare.breaktimer

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var editWork: EditText
    private lateinit var editBreak: EditText
    private lateinit var switchStrict: Switch
    private lateinit var buttonStartStop: Button
    private lateinit var statusText: TextView

    private val notifPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* user's choice either way */ }

    private val tickReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val phase = intent?.getStringExtra(TimerService.EXTRA_PHASE) ?: return
            val secondsLeft = intent.getIntExtra(TimerService.EXTRA_SECONDS_LEFT, 0)
            val m = secondsLeft / 60
            val s = secondsLeft % 60
            val label = if (phase == "WORK") "Working — next break in" else "On break — resumes work in"
            statusText.text = String.format("%s %02d:%02d", label, m, s)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editWork = findViewById(R.id.editWorkMinutes)
        editBreak = findViewById(R.id.editBreakSeconds)
        switchStrict = findViewById(R.id.switchStrictMode)
        buttonStartStop = findViewById(R.id.buttonStartStop)
        statusText = findViewById(R.id.textStatus)

        editWork.setText(Prefs.workMinutes(this).toString())
        editBreak.setText(Prefs.breakSeconds(this).toString())
        switchStrict.isChecked = Prefs.strictMode(this)

        switchStrict.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setStrictMode(this, isChecked)
        }

        buttonStartStop.setOnClickListener {
            if (Prefs.isTimerRunning(this)) stopTimer() else startTimer()
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        refreshButtonLabel()
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter(TimerService.ACTION_TICK)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(tickReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(tickReceiver, filter)
        }
        refreshButtonLabel()
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(tickReceiver)
    }

    private fun startTimer() {
        val workMinutes = editWork.text.toString().toIntOrNull()?.coerceIn(1, 180) ?: 20
        val breakSeconds = editBreak.text.toString().toIntOrNull()?.coerceIn(5, 600) ?: 20
        Prefs.setWorkMinutes(this, workMinutes)
        Prefs.setBreakSeconds(this, breakSeconds)

        val intent = Intent(this, TimerService::class.java).apply {
            action = TimerService.ACTION_START
        }
        ContextCompat.startForegroundService(this, intent)
        statusText.text = getString(R.string.status_starting)
        refreshButtonLabel()
    }

    private fun stopTimer() {
        val intent = Intent(this, TimerService::class.java).apply {
            action = TimerService.ACTION_STOP
        }
        startService(intent)
        statusText.text = getString(R.string.status_stopped)
        refreshButtonLabel()
    }

    private fun refreshButtonLabel() {
        buttonStartStop.text =
            if (Prefs.isTimerRunning(this)) getString(R.string.stop) else getString(R.string.start)
    }
}
