package com.eyecare.breaktimer

import android.content.Context

/**
 * All settings live in local SharedPreferences only. Nothing here is ever
 * uploaded anywhere — there is no code path in this app that touches a
 * network socket.
 */
object Prefs {
    private const val PREFS_NAME = "eyecare_prefs"
    private const val KEY_WORK_MINUTES = "work_minutes"
    private const val KEY_BREAK_SECONDS = "break_seconds"
    private const val KEY_STRICT_MODE = "strict_mode"
    private const val KEY_TIMER_RUNNING = "timer_running"

    fun workMinutes(context: Context): Int =
        prefs(context).getInt(KEY_WORK_MINUTES, 20)

    fun setWorkMinutes(context: Context, minutes: Int) {
        prefs(context).edit().putInt(KEY_WORK_MINUTES, minutes).apply()
    }

    fun breakSeconds(context: Context): Int =
        prefs(context).getInt(KEY_BREAK_SECONDS, 20)

    fun setBreakSeconds(context: Context, seconds: Int) {
        prefs(context).edit().putInt(KEY_BREAK_SECONDS, seconds).apply()
    }

    fun strictMode(context: Context): Boolean =
        prefs(context).getBoolean(KEY_STRICT_MODE, false)

    fun setStrictMode(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_STRICT_MODE, enabled).apply()
    }

    fun isTimerRunning(context: Context): Boolean =
        prefs(context).getBoolean(KEY_TIMER_RUNNING, false)

    fun setTimerRunning(context: Context, running: Boolean) {
        prefs(context).edit().putBoolean(KEY_TIMER_RUNNING, running).apply()
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
}
