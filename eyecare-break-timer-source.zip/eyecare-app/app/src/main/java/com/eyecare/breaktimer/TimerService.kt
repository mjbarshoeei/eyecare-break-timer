package com.eyecare.breaktimer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.CountDownTimer
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Owns all timing. Runs as a foreground service (with a low-priority status
 * notification) so the countdown keeps going while the phone is locked or
 * another app is open. Alternates WORK -> BREAK -> WORK -> ... until stopped.
 */
class TimerService : Service() {

    enum class Phase { WORK, BREAK }

    companion object {
        const val ACTION_START = "com.eyecare.breaktimer.action.START"
        const val ACTION_STOP = "com.eyecare.breaktimer.action.STOP"
        const val ACTION_SKIP_BREAK = "com.eyecare.breaktimer.action.SKIP_BREAK"
        const val ACTION_TICK = "com.eyecare.breaktimer.action.TICK"
        const val EXTRA_PHASE = "phase"
        const val EXTRA_SECONDS_LEFT = "seconds_left"
        const val CHANNEL_ID = "eyecare_timer_channel"
        const val CHANNEL_ID_BREAK = "eyecare_break_channel"
        const val NOTIF_ID = 1001
        const val NOTIF_ID_BREAK = 1002
    }

    private var timer: CountDownTimer? = null
    private var phase = Phase.WORK

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                Prefs.setTimerRunning(this, false)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_SKIP_BREAK -> {
                if (phase == Phase.BREAK) startWorkPhase()
                return START_STICKY
            }
            else -> {
                Prefs.setTimerRunning(this, true)
                startForeground(NOTIF_ID, buildStatusNotification("Eye care timer running", "Starting…"))
                startWorkPhase()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        timer?.cancel()
        Prefs.setTimerRunning(this, false)
        super.onDestroy()
    }

    private fun startWorkPhase() {
        timer?.cancel()
        phase = Phase.WORK
        val totalMs = Prefs.workMinutes(this) * 60_000L
        timer = object : CountDownTimer(totalMs, 1000L) {
            override fun onTick(msLeft: Long) {
                val secondsLeft = (msLeft / 1000).toInt()
                updateStatusNotification(secondsLeft, Phase.WORK)
                broadcastTick(Phase.WORK, secondsLeft)
            }
            override fun onFinish() = startBreakPhase()
        }.start()
    }

    private fun startBreakPhase() {
        timer?.cancel()
        phase = Phase.BREAK
        val breakSeconds = Prefs.breakSeconds(this)
        launchBreakScreen(breakSeconds)
        timer = object : CountDownTimer(breakSeconds * 1000L, 1000L) {
            override fun onTick(msLeft: Long) {
                val secondsLeft = (msLeft / 1000).toInt()
                updateStatusNotification(secondsLeft, Phase.BREAK)
                broadcastTick(Phase.BREAK, secondsLeft)
            }
            override fun onFinish() = startWorkPhase()
        }.start()
    }

    /**
     * Shows a full-screen-intent notification, which is the OS-sanctioned way for a
     * background app to bring up a full-screen UI without the "draw over other apps"
     * permission. Android reliably auto-launches it when the screen is off/locked.
     * While the screen is on and another app is in front, Android 10+ may instead just
     * show it as a heads-up banner the person taps to open the break screen — that
     * restriction applies to every non-alarm, non-call app and can't be bypassed from
     * here. The direct startActivity() below is a best-effort extra that only succeeds
     * if this app already has foreground standing at that moment; it fails silently
     * otherwise, so it's safe to always attempt.
     */
    private fun launchBreakScreen(breakSeconds: Int) {
        val activityIntent = Intent(this, BreakActivity::class.java).apply {
            putExtra(BreakActivity.EXTRA_BREAK_SECONDS, breakSeconds)
            putExtra(BreakActivity.EXTRA_STRICT_MODE, Prefs.strictMode(this@TimerService))
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            this, 0, activityIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID_BREAK)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.break_time_title))
            .setContentText(getString(R.string.break_time_body))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setContentIntent(fullScreenPendingIntent)
            .setAutoCancel(true)
            .build()

        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIF_ID_BREAK, notification)

        try {
            startActivity(activityIntent)
        } catch (_: Exception) {
            // Blocked background-activity-start; the full-screen notification above
            // is the fallback and will still open the break screen.
        }
    }

    private fun updateStatusNotification(secondsLeft: Int, phase: Phase) {
        val text = when (phase) {
            Phase.WORK -> "Next break in ${formatTime(secondsLeft)}"
            Phase.BREAK -> "Break ends in ${formatTime(secondsLeft)}"
        }
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIF_ID, buildStatusNotification("Eye care timer running", text))
    }

    private fun buildStatusNotification(title: String, text: String) =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

    private fun broadcastTick(phase: Phase, secondsLeft: Int) {
        sendBroadcast(
            Intent(ACTION_TICK).apply {
                putExtra(EXTRA_PHASE, phase.name)
                putExtra(EXTRA_SECONDS_LEFT, secondsLeft)
                setPackage(packageName)
            }
        )
    }

    private fun formatTime(totalSeconds: Int): String {
        val m = totalSeconds / 60
        val s = totalSeconds % 60
        return String.format("%02d:%02d", m, s)
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Timer status", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID_BREAK, "Break alerts", NotificationManager.IMPORTANCE_HIGH).apply {
                    setSound(null, null)
                }
            )
        }
    }
}
