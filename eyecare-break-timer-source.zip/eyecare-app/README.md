# Eye Care Break Timer

An offline, ad-free eye-care break reminder for Android. Set a work duration
and a break duration; when work time is up, a full-screen break overlay
takes over the screen until the break ends. Strict Mode hides the Skip
button so a break can't be dismissed early.

## Privacy

The `AndroidManifest.xml` never declares `android.permission.INTERNET` (or
`ACCESS_NETWORK_STATE`). On Android, permissions are opt-in and enforced by
the OS — without that permission the app is *not able* to open a network
socket, not just told not to. There is no ad SDK, no analytics SDK, and no
crash-reporting SDK anywhere in this project. All settings (durations,
Strict Mode) live in local `SharedPreferences` only. You can verify all of
this yourself by reading the manifest and the four source files in
`app/src/main/java/com/eyecare/breaktimer/`.

## Getting an installable APK

I can't produce a signed `.apk` binary directly from this chat — building
one needs the Android SDK/build tools, which aren't available in this
environment. This project is the complete, ready-to-build source. Two ways
to turn it into an APK, whichever is easier for you:

**Option A — Android Studio (no command line needed)**
1. Install [Android Studio](https://developer.android.com/studio) (free).
2. Open this folder as a project (File → Open).
3. Let it sync (first sync needs internet, to download the Android/Kotlin
   build tools — same as any Android project).
4. Build → Build Bundle(s) / APK(s) → Build APK(s).
5. The APK lands in `app/build/outputs/apk/debug/app-debug.apk`. Copy it to
   your phone (or Build → Generate Signed Bundle/APK for a release build)
   and install it.

**Option B — Let GitHub build it for you**
1. Push this folder to a new GitHub repo.
2. The included `.github/workflows/build-apk.yml` runs automatically on
   push (or via the "Run workflow" button) and builds `app-debug.apk` in
   GitHub's own cloud runner — no install on your machine at all.
3. Download the APK from the workflow run's **Artifacts** section, transfer
   it to your phone, and install it.

Either way, since this isn't from the Play Store, you'll need to allow
"install unknown apps" for whichever app you use to open the APK file (your
file manager or browser), in Android Settings.

## What's implemented

- Custom work duration (minutes) and break duration (seconds), editable on
  the home screen.
- A foreground service (`TimerService`) keeps the countdown running while
  your phone is locked or you're in another app.
- Full-screen break overlay (`BreakActivity`) with its own countdown.
- Strict Mode toggle: hides the Skip button and ignores the back button
  during a break.

## Two honest platform limitations

- **Break screen while your phone is actively in use:** Android reliably
  auto-launches the full-screen break overlay when your screen is off or
  locked. If your screen is on and you're using another app, Android 10+
  restricts apps from popping open a new full-screen activity uninvited
  (that's an OS anti-abuse rule, not something specific to this app) — in
  that case you'll get a high-priority notification banner instead, and
  tapping it opens the break screen. This matches how most non-system
  alarm/reminder apps behave.
- **Strict Mode and the Home button:** Strict Mode hides Skip and blocks
  the back button, but a regular app cannot also block the Home/Recents
  buttons — that needs Android's kiosk-mode APIs, which require the app to
  be set as your phone's "device owner" (normally an enterprise-management
  feature). So Strict Mode makes a break hard to skip, not physically
  impossible to leave.

## Project structure

```
app/src/main/java/com/eyecare/breaktimer/
  MainActivity.kt    – home screen: settings + start/stop
  TimerService.kt     – foreground service, owns the work/break countdown
  BreakActivity.kt    – full-screen break overlay
  Prefs.kt             – local-only settings storage
app/src/main/res/      – layouts, strings, icons
.github/workflows/      – CI workflow that builds a debug APK on push
```

Minimum Android version: 8.0 (API 26).
